create index IX_5B21CFC8 on AAA_Customer (groupId);
create index IX_F32FC896 on AAA_Customer (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_3E1D7C98 on AAA_Customer (uuid_[$COLUMN_LENGTH:75$], groupId);

create index IX_D9C76FCD on FOO_Customer (groupId);
create index IX_CA4D5E31 on FOO_Customer (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_AF49BCF3 on FOO_Customer (uuid_[$COLUMN_LENGTH:75$], groupId);