create table AAA_Customer (
	uuid_ VARCHAR(75) null,
	customerId LONG not null primary key,
	customerName VARCHAR(75) null,
	customerEmail VARCHAR(75) null,
	customerAddress VARCHAR(75) null,
	customerContact VARCHAR(75) null,
	customerNRIC VARCHAR(75) null,
	start_date DATE null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	serviceId LONG
);

create table FOO_Customer (
	uuid_ VARCHAR(75) null,
	customerId LONG not null primary key,
	customerName VARCHAR(75) null,
	customerEmail VARCHAR(75) null,
	customerAddress VARCHAR(75) null,
	customerContact VARCHAR(75) null,
	customerNRIC VARCHAR(75) null,
	start_date DATE null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	serviceId LONG
);