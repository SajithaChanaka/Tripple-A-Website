package AAACustomer.constants;

/**
 * @author sajitha
 */
public class AAACustomerPortletKeys {

	public static final String AAACUSTOMER =
		"AAACustomer_AAACustomerPortlet";

}