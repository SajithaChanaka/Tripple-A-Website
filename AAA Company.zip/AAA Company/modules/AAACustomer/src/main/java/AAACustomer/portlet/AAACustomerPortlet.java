package AAACustomer.portlet;

import AAACustomer.constants.AAACustomerPortletKeys;
import AAACustomerService.model.Customer;
import AAACustomerService.service.CustomerLocalServiceUtil;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

/**
 * @author sajitha
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=AAACustomer",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + AAACustomerPortletKeys.AAACUSTOMER,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class AAACustomerPortlet extends MVCPortlet {
	
	//CustomerPortlet
	public void addCustomer(ActionRequest request, ActionResponse response)
            throws Exception {

	/* _updateCustomer(request); */
		
		String name = ParamUtil.getString(request, "customerName");
	    String email = ParamUtil.getString(request, "customerEmail");
		String address = ParamUtil.getString(request, "customerAddress");
		String nationalID = ParamUtil.getString(request, "customerNRIC");
		String contact = ParamUtil.getString(request, "customerContact");

		System.out.println("Name: " + name);
		System.out.println("Email: " + email);
		System.out.println("Address: " + address);
		System.out.println("National ID Number: " + nationalID);
		System.out.println("Contact Number: " + contact);

		/** --Auto Increment-- **/
		long customerId = CounterLocalServiceUtil.increment();
		/** --Created Feedback Object-- **/
		Customer customer = CustomerLocalServiceUtil.createCustomer(customerId);
		/** --Insert String Values to Model-- **/
		customer.setCustomerName(name);
		customer.setCustomerEmail(email);
		customer.setCustomerAddress(address);
		customer.setCustomerNRIC(nationalID);
		customer.setCustomerContact(contact);
		/** --Insert Feedback-- **/
		CustomerLocalServiceUtil.addCustomer(customer);

		System.out.println("Customer Has Been Successfully Added");

         sendRedirect(request, response);
    }

    public void deleteCustomer(ActionRequest request, ActionResponse response)
        throws Exception {

        long customerId = ParamUtil.getLong(request, "customerId");

        CustomerLocalServiceUtil.deleteCustomer(customerId);

        sendRedirect(request, response);
    }

    public void updateCustomer(ActionRequest request, ActionResponse response)
        throws Exception {
    	
    	long customerID = ParamUtil.getLong(request, "customerId");
    	String name = ParamUtil.getString(request, "customerName");
	    String email = ParamUtil.getString(request, "customerEmail");
		String address = ParamUtil.getString(request, "customerAddress");
		String nationalID = ParamUtil.getString(request, "customerNRIC");
		String contact = ParamUtil.getString(request, "customerContact");
    	System.out.print(customerID);

    	/** --Get Customer-- **/
    	Customer customer = CustomerLocalServiceUtil.getCustomer(customerID);
    	/** --Insert String Values to Model-- **/
    	customer.setCustomerName(name);
    	customer.setCustomerEmail(email);
    	customer.setCustomerAddress(address);
    	customer.setCustomerNRIC(nationalID);
    	customer.setCustomerContact(contact);
    	/** --Insert Feedback-- **/

CustomerLocalServiceUtil.updateCustomer(customer);

        _updateCustomer(request);

        sendRedirect(request, response);
    }

    private Customer _updateCustomer(ActionRequest request)
        throws PortalException, SystemException {

	/*
	 * // Collect all information from JSP long customerId =
	 * ParamUtil.getLong(request, "customerId"); String name =
	 * ParamUtil.getString(request, "customerName"); String email =
	 * ParamUtil.getString(request, "customerEmail"); String address =
	 * ParamUtil.getString(request, "customerAddress"); String national_Id =
	 * ParamUtil.getString(request, "customerNRIC"); String contact =
	 * ParamUtil.getString(request, "customerContact"); long serviceId =
	 * ParamUtil.getLong(request, "serviceId");
	 * 
	 * int year = ParamUtil.getInteger(request, "start_dateYear"); int month =
	 * ParamUtil.getInteger(request, "start_dateMonth"); int day =
	 * ParamUtil.getInteger(request, "start_dateDay"); int hour =
	 * ParamUtil.getInteger(request, "start_dateHour"); int minute =
	 * ParamUtil.getInteger(request, "start_dateMinute"); int amPm =
	 * ParamUtil.getInteger(request, "start_dateAmPm");
	 * 
	 * if (amPm == Calendar.PM) { hour += 12; }
	 * 
	 * ServiceContext serviceContext = ServiceContextFactory.getInstance(
	 * Customer.class.getName(), request);
	 */

       Customer customer = null;
        
	/*
	 * //Check old customer or new Customer if (customerId <= 0) {
	 * System.out.println("Add Customer "); // add Customer Method }
	 * 
	 * 
	 * else { System.out.println("Update Customer "); customer =
	 * CustomerLocalServiceUtil.getCustomer(customerId); //Call update method
	 * customer = CustomerLocalServiceUtil.updateCustomer(
	 * serviceContext.getUserId(), customerId, name, email, address, national_Id,
	 * contact, month, day, year, hour, minute, serviceId, serviceContext); }
	 */
        
        return customer;
    }


}

